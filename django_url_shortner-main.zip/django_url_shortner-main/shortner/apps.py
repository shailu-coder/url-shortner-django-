from django.apps import AppConfig


class ShortnerConfig(AppConfig):
    name = 'shortner'
